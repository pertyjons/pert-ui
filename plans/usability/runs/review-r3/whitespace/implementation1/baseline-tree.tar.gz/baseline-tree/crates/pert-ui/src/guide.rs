//! A practical introduction to pert-ui, one chapter per area of the library.
//!
//! Start with [getting started](getting_started): a complete window, the data
//! contracts, a saved workspace and a custom widget. The other chapters can be
//! read in any order:
//!
//! - [State](state): which way to choose, signals and controls, worker
//!   results, live data, a settings form and recovery.
//! - [Authoritative values](authoritative_values): parameters, local edit
//!   gestures, host notifications, effective overlays and external authority.
//! - [Layout and views](layout): which way to choose for children from data,
//!   region layouts, splits, tabs, floating and native windows, workspaces,
//!   large collections, an editable list of records, zoomable content and
//!   drag and drop.
//! - [Controls](controls): buttons, boolean and choice controls, sliders, text
//!   and numeric editors, progress, inline controls and toolbars.
//! - [Surfaces](surfaces): selects, popovers, tooltips, menus, dialogs and
//!   notifications.
//! - [Appearance](appearance): themes, density, zoom, shapes, fonts, icons,
//!   images and SVG.
//! - [Diagnostics](diagnostics): keyboard input, inspection, screenshots,
//!   serialization and profiling.
//! - [Testing an application](testing): reading what a headless runtime
//!   shows, clicks, text, in-place editors, keys and chords, settling, list
//!   rows, background work, the close policy and a CPU capture.
//! - [Custom widgets](custom_widgets): a component that follows a binding,
//!   phases and writes, pointer gestures that converge, a control that edits
//!   a value, clicks, held keys,
//!   described children, inspection, an inspector over an application
//!   document and building an application.
//!
//! Every example is a doctest that imports only the public API. Each item's own
//! reference page holds its complete contract: defaults, limits, errors and
//! lifecycle. The repository's design notes explain decisions and also contain
//! proposals; they are not a list of available functions.

// Every chapter imports the crate root so that its prose links items by their
// plain names; the import is for rustdoc's link resolution only.
//
// Every chapter also appends the same link definitions, so its prose can name items
// behind optional features: an intra-doc link when the feature is enabled, and a
// docs.rs link (whose build enables them all) when it is not.

pub mod getting_started {
    //! Getting started: a first window, composition, data contracts, a saved
    //! workspace and a custom widget.
    //!
    #![doc = include_str!("guide/getting-started.md")]
    #![cfg_attr(feature = "native", doc = "```no_run")]
    #![cfg_attr(not(feature = "native"), doc = "```text")]
    #![doc = include_str!("../examples/getting_started.rs")]
    #![doc = "```"]
    #![doc = include_str!("guide/getting-started-continued.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod state {
    //! State: which way to choose, signals and controls, worker results, live
    //! data, a settings form and recovery.
    //!
    #![doc = include_str!("guide/state.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod authoritative_values {
    //! Authoritative values: parameters, local edit gestures, host
    //! notifications, effective overlays and external authority.
    //!
    #![doc = include_str!("guide/authoritative-values.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod layout {
    //! Layout and views: containers, region layouts, splits, tabs, windows,
    //! workspaces, collections, zoomable content and drag and drop.
    //!
    #![doc = include_str!("guide/layout.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod controls {
    //! Controls: actions, boolean and choice controls, sliders, text and numeric
    //! editors, progress, inline controls and toolbars.
    //!
    #![doc = include_str!("guide/controls.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod surfaces {
    //! Surfaces: selects, popovers, tooltips, menus, dialogs and notifications.
    //!
    #![doc = include_str!("guide/surfaces.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod appearance {
    //! Appearance: themes, density, zoom, shapes, fonts, icons, images and SVG.
    //!
    #![doc = include_str!("guide/appearance.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod diagnostics {
    //! Diagnostics: keyboard input, inspection, screenshots, serialization and
    //! profiling.
    //!
    #![doc = include_str!("guide/diagnostics.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod testing {
    //! Testing an application: reading what a headless runtime shows, clicks,
    //! text, keys and chords, settling, list rows, background work, the close
    //! policy and a CPU capture.
    //!
    #![doc = include_str!("guide/testing.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}

pub mod custom_widgets {
    //! Custom widgets: a component that follows a binding, phases and writes,
    //! pointer gestures, clicks, held keys, described children, inspection and
    //! an application around them.
    //!
    #![doc = include_str!("guide/custom-widgets.md")]
    #![cfg_attr(feature = "native", doc = include_str!("guide/links/desktop.md"))]
    #![cfg_attr(not(feature = "native"), doc = include_str!("guide/links/no-desktop.md"))]
    #![cfg_attr(feature = "images", doc = include_str!("guide/links/images.md"))]
    #![cfg_attr(not(feature = "images"), doc = include_str!("guide/links/no-images.md"))]
    #![cfg_attr(feature = "svg", doc = include_str!("guide/links/svg.md"))]
    #![cfg_attr(not(feature = "svg"), doc = include_str!("guide/links/no-svg.md"))]
    #![cfg_attr(feature = "cpu", doc = include_str!("guide/links/cpu.md"))]
    #![cfg_attr(not(feature = "cpu"), doc = include_str!("guide/links/no-cpu.md"))]
    #[allow(unused_imports)]
    use crate::*;
}
